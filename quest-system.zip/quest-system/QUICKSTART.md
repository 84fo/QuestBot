# 🚀 QUICK START - Quest System

## 📋 What You Have

**Three ways to complete Discord quests:**

1. **CLI Tool** (Easiest) - Run from command line
2. **Discord Bot** - Use `/advanced` command in Discord
3. **Direct Code** - Integrate into your project

---

## ⚡ FASTEST SETUP (5 minutes)

### Step 1: Install
```bash
npm install
```

### Step 2: Set Token
```bash
export DISCORD_TOKEN=your_discord_token_here
```

### Step 3: Run
```bash
# Complete ALL quests
node cli-quest-tool.js all

# Or specific types
node cli-quest-tool.js video
node cli-quest-tool.js desktop
node cli-quest-tool.js stream
node cli-quest-tool.js activity
```

**That's it!** ✅

---

## 🤖 Using Discord Bot

```bash
# Setup
npm install
echo "DISCORD_TOKEN=YOUR_BOT_TOKEN" > .env

# Start
node bot-advanced.js

# In Discord: /advanced
# Then click buttons to complete quests
```

---

## 📖 Full Guide

See `ADVANCED_QUEST_GUIDE.md` for:
- Detailed setup
- How spoofing works
- Advanced configuration
- Troubleshooting

---

## 🔐 Get Your Discord Token

1. Open Discord in browser
2. Press `F12` (DevTools)
3. Go to **Network** tab
4. Refresh page
5. Click any request
6. Look for **Authorization header**
7. Copy the token (after "Authorization: ")

⚠️ **NEVER share this token!**

---

## ✅ What Works

✅ Video quests - 100% guaranteed  
✅ Activity quests - 100% guaranteed  
✅ Desktop quests - Advanced spoofing (80%+)  
✅ Stream quests - Advanced simulation (80%+)  

---

## 🔥 Example

```bash
$ node cli-quest-tool.js all

🚀 Starting Advanced Quest Completion System...

📋 Found 3 quests

⏳ Processing: Watch Video (WATCH_VIDEO)...
✅ Video quest completed

⏳ Processing: Play Game (PLAY_ON_DESKTOP)...
   → Generated fake process ID: 15234
   → Sending heartbeats...
   → Simulating gameplay...
✅ Desktop quest completed

⏳ Processing: Stream (STREAM_ON_DESKTOP)...
   → Created stream session
   → Sending stream heartbeats...
✅ Stream quest completed

✅ Total Completed: 3/3
```

---

**That's all you need to know to get started!** 🎉
